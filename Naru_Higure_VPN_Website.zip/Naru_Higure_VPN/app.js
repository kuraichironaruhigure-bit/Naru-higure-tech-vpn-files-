// Add your Supabase project URL and anon/public key below after creating your project.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";
const BUCKET = "vpn-files";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_ANON_KEY.startsWith("PASTE_");
const db = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const $ = (id) => document.getElementById(id);
let allFiles = [];

function message(id, text, good=false) {
  const el=$(id); el.textContent=text; el.style.color=good?"#71d99c":"#f06b78";
}
function escapeHtml(s="") {
  return String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function prettySize(n) {
  if(n<1024) return n+" B"; if(n<1048576) return (n/1024).toFixed(1)+" KB"; return (n/1048576).toFixed(1)+" MB";
}
function renderFiles(files) {
  const list=$("fileList");
  if(!files.length){list.innerHTML='<div class="empty">No approved files yet. Be the first to contribute!</div>';return;}
  list.innerHTML=files.map(f=>`<article class="file-card">
    <span class="tag">${escapeHtml((f.file_name.split(".").pop()||"file").toUpperCase())}</span>
    <h3>${escapeHtml(f.title)}</h3><p>${escapeHtml(f.description||"No description provided.")}</p>
    <div class="file-meta"><span class="small">${prettySize(f.file_size||0)}</span><button class="download" data-download="${escapeHtml(f.id)}">DOWNLOAD ↓</button></div>
  </article>`).join("");
  list.querySelectorAll("[data-download]").forEach(b=>b.addEventListener("click",()=>downloadFile(b.dataset.download,b)));
}
async function loadFiles() {
  if(!db){$("fileList").innerHTML='<div class="empty">Website setup required: add your Supabase URL and public key in app.js, then run the SQL setup in README.</div>';return;}
  const {data,error}=await db.from("vpn_uploads").select("id,title,description,file_name,file_size,created_at").eq("status","approved").order("created_at",{ascending:false});
  if(error){$("fileList").innerHTML='<div class="empty">Could not load files. Check the Supabase setup.</div>';return;}
  allFiles=data||[]; $("approvedCount").textContent=allFiles.length; renderFiles(allFiles);
}
async function downloadFile(id,button) {
  if(!db)return;
  button.textContent="PLEASE WAIT…";
  const f=allFiles.find(x=>x.id===id); if(!f){button.textContent="DOWNLOAD ↓";return;}
  const {data,error}=await db.storage.from(BUCKET).createSignedUrl(f.id+"/"+f.file_name,90);
  if(error){button.textContent="TRY AGAIN";return;}
  const a=document.createElement("a");a.href=data.signedUrl;a.download=f.file_name;a.rel="noopener";document.body.appendChild(a);a.click();a.remove();button.textContent="DOWNLOAD ↓";
}
$("search").addEventListener("input",e=>{const q=e.target.value.toLowerCase();renderFiles(allFiles.filter(f=>(f.title+" "+f.description+" "+f.file_name).toLowerCase().includes(q)));});
$("vpnFile").addEventListener("change",e=>$("fileName").textContent=e.target.files[0]?.name||"Choose a file (20 MB max)");
$("uploadForm").addEventListener("submit",async e=>{
  e.preventDefault(); if(!db){message("uploadMessage","Website setup is not complete yet.");return;}
  const file=$("vpnFile").files[0], title=$("displayName").value.trim(), description=$("description").value.trim();
  const allowed=["json","ovpn","conf","npv","npvt","txt"], ext=(file?.name.split(".").pop()||"").toLowerCase();
  if(!file||!allowed.includes(ext)){message("uploadMessage","Choose a supported VPN file type.");return;}
  if(file.size>20*1024*1024){message("uploadMessage","File is larger than 20 MB.");return;}
  message("uploadMessage","Uploading…");
  const id=crypto.randomUUID(), path=id+"/"+file.name;
  const up=await db.storage.from(BUCKET).upload(path,file,{upsert:false,contentType:file.type||"application/octet-stream"});
  if(up.error){message("uploadMessage","Upload failed: "+up.error.message);return;}
  const ins=await db.from("vpn_uploads").insert({id,title,description,file_name:file.name,file_size:file.size,storage_path:path,status:"pending"});
  if(ins.error){await db.storage.from(BUCKET).remove([path]);message("uploadMessage","Could not submit file: "+ins.error.message);return;}
  $("uploadForm").reset();$("fileName").textContent="Choose a file (20 MB max)";
  message("uploadMessage","Submitted! Your file will appear after administrator approval.",true);
});
$("adminOpen").addEventListener("click",()=>{$("adminDialog").showModal();});
$("loginButton").addEventListener("click",async()=>{
  if(!db){message("adminMessage","Website setup is not complete.");return;}
  message("adminMessage","Signing in…");
  const {error}=await db.auth.signInWithPassword({email:$("adminEmail").value,password:$("adminPassword").value});
  if(error){message("adminMessage","Sign-in failed. Check your details.");return;}
  const {data}=await db.auth.getUser();
  if(data.user?.app_metadata?.role!=="admin"){await db.auth.signOut();message("adminMessage","This account is not an administrator.");return;}
  $("loginPanel").hidden=true;$("reviewPanel").hidden=false;loadPending();
});
$("logoutButton").addEventListener("click",async()=>{await db.auth.signOut();$("reviewPanel").hidden=true;$("loginPanel").hidden=false;});
async function loadPending(){
  const {data,error}=await db.from("vpn_uploads").select("*").eq("status","pending").order("created_at",{ascending:true});
  if(error){$("pendingList").textContent="Could not load submissions.";return;}
  if(!data?.length){$("pendingList").textContent="No pending submissions.";return;}
  $("pendingList").innerHTML=data.map(f=>`<div class="pending-item"><strong>${escapeHtml(f.title)}</strong><p>${escapeHtml(f.file_name)} · ${prettySize(f.file_size||0)}<br>${escapeHtml(f.description||"No description")}</p><div class="pending-actions"><button class="approve" data-approve="${f.id}">APPROVE</button><button class="reject" data-reject="${f.id}">REJECT</button></div></div>`).join("");
  $("pendingList").querySelectorAll("[data-approve]").forEach(b=>b.onclick=()=>moderate(b.dataset.approve,"approved"));
  $("pendingList").querySelectorAll("[data-reject]").forEach(b=>b.onclick=()=>moderate(b.dataset.reject,"rejected"));
}
async function moderate(id,status){
  const {error}=await db.from("vpn_uploads").update({status}).eq("id",id);
  if(error){alert("Could not update this file.");return;} await loadPending(); await loadFiles();
}
loadFiles();
