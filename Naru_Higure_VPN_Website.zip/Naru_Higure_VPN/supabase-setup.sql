-- NARU HIGURE VPN database setup (run in Supabase SQL Editor)
-- Create a PRIVATE storage bucket. Files are only downloadable after approval.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('vpn-files', 'vpn-files', false, 20971520, null)
on conflict (id) do update set public=false, file_size_limit=20971520;

create table if not exists public.vpn_uploads (
  id uuid primary key,
  title text not null check (char_length(title) between 1 and 40),
  description text default '',
  file_name text not null,
  file_size bigint not null default 0,
  storage_path text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

alter table public.vpn_uploads enable row level security;

-- Anyone may submit metadata; submissions remain private until approved.
drop policy if exists "Anyone can submit VPN metadata" on public.vpn_uploads;
create policy "Anyone can submit VPN metadata" on public.vpn_uploads
for insert to anon, authenticated with check (status='pending');

-- Everyone can view approved entries only.
drop policy if exists "Public can view approved VPN files" on public.vpn_uploads;
create policy "Public can view approved VPN files" on public.vpn_uploads
for select to anon, authenticated using (status='approved');

-- Admins can view and moderate every entry. Admin role must be set in app_metadata.
drop policy if exists "Admins can view all submissions" on public.vpn_uploads;
create policy "Admins can view all submissions" on public.vpn_uploads
for select to authenticated using ((auth.jwt()->'app_metadata'->>'role')='admin');

drop policy if exists "Admins can moderate submissions" on public.vpn_uploads;
create policy "Admins can moderate submissions" on public.vpn_uploads
for update to authenticated
using ((auth.jwt()->'app_metadata'->>'role')='admin')
with check ((auth.jwt()->'app_metadata'->>'role')='admin');

-- Storage: anonymous and signed-in visitors may upload; file is private until approved.
drop policy if exists "Anyone can upload VPN files" on storage.objects;
create policy "Anyone can upload VPN files" on storage.objects
for insert to anon, authenticated
with check (bucket_id='vpn-files');

-- Signed download URLs can only be created for approved files, or by an admin.
drop policy if exists "Approved files can be downloaded" on storage.objects;
create policy "Approved files can be downloaded" on storage.objects
for select to anon, authenticated
using (
  bucket_id='vpn-files'
  and (
    exists (
      select 1 from public.vpn_uploads u
      where u.storage_path = name and u.status='approved'
    )
    or (auth.jwt()->'app_metadata'->>'role')='admin'
  )
);

-- Admin can remove stored files when cleaning up rejected submissions.
drop policy if exists "Admins can delete VPN files" on storage.objects;
create policy "Admins can delete VPN files" on storage.objects
for delete to authenticated
using (bucket_id='vpn-files' and (auth.jwt()->'app_metadata'->>'role')='admin');

-- IMPORTANT: after creating your own admin user in Authentication > Users,
-- replace the email below and run this separately:
-- update auth.users
-- set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
-- where email = 'YOUR_ADMIN_EMAIL';
